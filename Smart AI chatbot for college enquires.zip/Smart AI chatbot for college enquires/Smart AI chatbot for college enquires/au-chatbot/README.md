npm install# Anna University AI Chatbot
## No API Key Needed — Runs 100% Locally!

### How to Run

1. Install dependencies:
   npm install

2. Start the dev server:
   npm run dev

3. Open browser:
   http://localhost:5173

### Requirements
- Node.js 18+ (https://nodejs.org)

### Features
- Courses, Fees, Admissions, Placements, Rankings, Campus, Scholarships
- Knowledge Base updated with 2025-26 data
- Works fully offline — no internet needed after npm install
npm cache clean --force
Remove-Item -Recurse -Force node_modules
npm install
npm run dev