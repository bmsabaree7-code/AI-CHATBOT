import { useState, useRef, useEffect } from "react";

// ─── Knowledge Base ───────────────────────────────────────────────────────────
const KB = {
  greetings: ["hi", "hello", "hey", "good morning", "good afternoon", "good evening", "hii", "helo", "hai"],

  topics: {
    about: {
      keywords: ["about", "what is anna", "anna university", "overview", "introduction", "history", "founded", "naac", "ugc", "aicte"],
      answer: `🏛️ **About Anna University**

- **Founded:** 4th September 1978, named after C.N. Annadurai
- **Type:** Public State Technical University
- **Location:** Sardar Patel Road, Guindy, Chennai – 600 025
- **Approvals:** UGC ✔ | AICTE ✔ | AIU Member ✔
- **NAAC Grade:** A++
- **Website:** annauniv.edu
- **Affiliated Colleges:** 500+ across Tamil Nadu`,
    },

    campuses: {
      keywords: ["campus", "campuses", "college", "ceg", "act", "mit", "sap", "guindy", "chromepet", "regional", "coimbatore", "madurai"],
      answer: `🏫 **Anna University Campuses**

**Main Campuses (Chennai):**
- CEG – College of Engineering, Guindy (est. 1794) — Main Campus
- ACT – Alagappa College of Technology (est. 1944)
- MIT – Madras Institute of Technology, Chromepet (est. 1949)
- SAP – School of Architecture & Planning (est. 1957)

**Regional Campuses:**
- Coimbatore | Tiruchirappalli | Madurai | Tirunelveli`,
    },

    courses: {
      keywords: ["course", "courses", "programme", "program", "degree", "be", "btech", "barch", "me", "mtech", "mba", "mca", "msc", "phd", "ug", "pg", "undergraduate", "postgraduate", "branch", "department", "cse", "ece", "eee", "mechanical", "civil", "it", "information technology", "aeronautical", "biomedical", "chemical"],
      answer: `📚 **Courses Offered**

**UG Programs (4-year B.E./B.Tech):**
- Computer Science & Engineering (CSE)
- Electronics & Communication (ECE)
- Electrical & Electronics (EEE)
- Mechanical Engineering
- Civil Engineering
- Information Technology (IT)
- Chemical | Aeronautical | Automobile
- Biomedical | Biotechnology | Petroleum | Textile

**Other UG:** B.Arch (5-year) | B.Planning

**PG Programs:**
- M.E. / M.Tech — 50+ specializations
- MBA | MCA | M.Sc (2-year & 5-year integrated)
- M.Arch | M.Planning

**Research:** Ph.D. in all departments

**Online:** MOOCs via SWAYAM — AI, DBMS, OS, Software Engg, etc.`,
    },

    admission: {
      keywords: ["admission", "apply", "application", "eligibility", "how to join", "tnea", "tancet", "gate", "nata", "counselling", "counseling", "cutoff", "cut off", "merit", "rank", "join", "enroll", "entrance", "exam", "2026"],
      answer: `📋 **Admission Process**

**For B.E./B.Tech (UG):**
- Entrance: TNEA Counselling (no separate exam)
- Eligibility: 10+2 with Physics, Chemistry, Maths — min 45% (40% for SC/ST)
- Merit-based on 12th marks
- Apply at: **tneaonline.org**
- TNEA 2026 Counselling: Expected May 2026

**For B.Arch:**
- NATA scores considered

**For M.E./M.Tech (PG):**
- TANCET or GATE scores
- TANCET 2026 Exam: May 9, 2026

**For MBA / MCA:**
- TANCET exam | MBA cutoff: ~7080–7090

**For Ph.D.:**
- University entrance test + Interview

**International Students:**
- NRI / Foreign Nationals — 5% supernumerary seats`,
    },

    fees: {
      keywords: ["fee", "fees", "cost", "tuition", "payment", "charge", "amount", "money", "expense", "rupees", "lakh", "government quota", "management quota"],
      answer: `💰 **Fee Structure**

**B.E./B.Tech:**
- Government Quota: ₹30,000 – ₹48,000 per year
- Total 4-year cost: ~₹1.38 Lakhs (Govt)
- Management Quota: up to ₹2.2 Lakhs per year

**M.E. / M.Tech:**
- Total course fee: ₹82,000 – ₹2.05 Lakhs

**MBA / MCA:**
- ₹48,000 – ₹2 Lakhs (varies by quota)

> Note: SC/ST candidates may get additional fee concessions. Fees vary by campus and department.`,
    },

    placements: {
      keywords: ["placement", "placements", "job", "jobs", "recruit", "recruiter", "package", "lpa", "salary", "career", "company", "companies", "google", "microsoft", "amazon", "tcs", "infosys", "wipro", "highest", "average", "median"],
      answer: `💼 **Placements (NIRF 2025 Data)**

- **Placement Cell:** Centre for University-Industry Collaboration (CUIC)
- **Total Students Placed:** 1,684
  - UG: 1,161 | PG: 523
- **Median Package:** ₹6 – ₹7.5 LPA
- **Average Package:** ₹8.54 LPA
- **Highest Package:** ₹40 LPA

**Top Recruiters:**
Google | Microsoft | Amazon | TCS | Infosys | Cognizant | Wipro | Accenture | Deloitte | Bank of America | Barclays | DE Shaw | Walmart Labs | CISCO | Reliance`,
    },

    rankings: {
      keywords: ["rank", "ranking", "nirf", "qs", "rating", "position", "score", "best", "top"],
      answer: `🏆 **Rankings & Ratings**

**NIRF 2025:**
- 🥇 14th Overall
- 🥇 13th in Engineering
- 🥇 20th University

**QS World University Rankings 2026:**
- 465th Globally
- 10th Among Indian Institutions
- 252nd in Engineering & Technology

**NAAC Grade:** A++`,
    },

    campus_life: {
      keywords: ["hostel", "facility", "facilities", "library", "sports", "canteen", "food", "lab", "laboratory", "infrastructure", "accommodation", "stay", "campus life", "life", "app"],
      answer: `🏠 **Campus Facilities**

**Academic:**
- Digital Knowledge Centre (Central Library)
- DMG MORI 5-Axis Machining Centre
- Advanced Drives & Machines Lab
- 5G Use Case Lab | Bioprocess Lab
- Sugar Research Institute
- Mechatronics Institute

**Student Life:**
- Separate Boys' & Girls' Hostels
- Canteen & Food Courts
- Sports: Cricket, Football, Basketball & more
- Auditoriums & Seminar Halls

**Other:**
- Entrepreneurship Development Park
- Convention Centre
- Anna University App (Play Store & App Store)`,
    },

    scholarships: {
      keywords: ["scholarship", "scholarships", "financial", "aid", "free", "concession", "stipend", "sc", "st", "obc", "merit"],
      answer: `🎓 **Scholarships & Financial Aid**

- **Merit Scholarships:** For academic excellence & extracurricular achievements
- **State Govt Schemes:** Tamil Nadu government scholarships
- **Central Govt Schemes:** National-level scholarships
- **SC/ST/OBC:** Fee concessions & need-based financial aid
- **Free Hostel:** Available for eligible students

> Visit annauniv.edu/scholarships for the latest schemes and application deadlines.`,
    },

    transfer: {
      keywords: ["transfer", "lateral", "migration", "change college", "move"],
      answer: `🔄 **Transfer Admissions**

- Minimum 1 academic year completed at current institution
- Must have passed all exams with no backlogs
- Same branch transfers only
- Subject to seat vacancy
- Processed through DTE Chennai
- Consent required from both college principals`,
    },

    contact: {
      keywords: ["contact", "address", "phone", "email", "website", "reach", "location", "where"],
      answer: `📞 **Contact Anna University**

- **Website:** annauniv.edu
- **Address:** Sardar Patel Road, Guindy, Chennai – 600 025, Tamil Nadu
- **Location:** Near Guindy Metro Station

For admissions: **tneaonline.org**
For PG admissions: **annauniv.edu/tancet**`,
    },
  },
};

// ─── AI Matching Engine ───────────────────────────────────────────────────────
function getResponse(userInput) {
  const input = userInput.toLowerCase().trim();

  // Greeting
  if (KB.greetings.some((g) => input.includes(g))) {
    return `👋 **Hello! Welcome to Anna University Assistant!**\n\nI'm here to help you with everything about Anna University, Chennai.\n\nYou can ask me about:\n- Courses & Departments\n- Admissions & Eligibility\n- Fee Structure\n- Placements & Recruiters\n- Campus Facilities\n- Rankings & Scholarships\n\nWhat would you like to know? 😊`;
  }

  // Thank you
  if (["thank", "thanks", "thank you", "ok thanks", "okay thanks"].some((t) => input.includes(t))) {
    return `😊 You're welcome! Feel free to ask anything else about Anna University. I'm here to help!`;
  }

  // Bye
  if (["bye", "goodbye", "see you", "exit", "quit"].some((b) => input.includes(b))) {
    return `👋 Goodbye! Best of luck with your journey at Anna University. Feel free to come back anytime!`;
  }

  // Match topics by keywords — score each topic
  let bestTopic = null;
  let bestScore = 0;

  for (const [, topic] of Object.entries(KB.topics)) {
    const score = topic.keywords.filter((kw) => input.includes(kw)).length;
    if (score > bestScore) {
      bestScore = score;
      bestTopic = topic;
    }
  }

  if (bestTopic && bestScore > 0) return bestTopic.answer;

  // Fallback
  return `🤔 I'm not sure about that specific question. You can ask me about:\n\n- 📚 **Courses** — What courses does AU offer?\n- 💰 **Fees** — What is the fee structure?\n- 📋 **Admissions** — How to apply?\n- 💼 **Placements** — Job packages & recruiters\n- 🏆 **Rankings** — NIRF & QS rankings\n- 🏠 **Campus** — Facilities & hostels\n- 🎓 **Scholarships** — Available aid\n\nOr visit **annauniv.edu** for more details.`;
}

// ─── Format helper ────────────────────────────────────────────────────────────
function formatText(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/^[-•] (.+)$/gm, "<li>$1</li>")
    .replace(/(<li>.*?<\/li>\n?)+/g, (m) => `<ul style="padding-left:18px;margin:6px 0">${m}</ul>`)
    .replace(/\n\n/g, "<br/><br/>")
    .replace(/\n/g, "<br/>");
}

const QUICK_TOPICS = [
  { icon: "📚", label: "Courses",      q: "What courses does Anna University offer?" },
  { icon: "💰", label: "Fees",         q: "What is the fee structure?" },
  { icon: "📋", label: "Admissions",   q: "How to apply for admission?" },
  { icon: "💼", label: "Placements",   q: "Tell me about placements and top recruiters" },
  { icon: "🏆", label: "Rankings",     q: "What are the NIRF and QS rankings?" },
  { icon: "🏠", label: "Campus",       q: "What campus facilities are available?" },
  { icon: "🎓", label: "Scholarships", q: "What scholarships are available?" },
  { icon: "📝", label: "Entrance",     q: "Explain TNEA and TANCET entrance exams" },
];

// ─── Main Component ───────────────────────────────────────────────────────────
export default function App() {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content:
        "👋 **Welcome to Anna University Smart Assistant!**\n\nI'm your AI guide for everything about **Anna University, Chennai** — admissions, courses, fees, placements, campus life, and more.\n\n✅ **We have updated our knowledge base** with the latest 2025–26 information!\n\nAsk me anything or tap a topic above! 🎓",
    },
  ]);
  const [input, setInput]         = useState("");
  const [loading, setLoading]     = useState(false);
  const [hoveredChip, setHovered] = useState(null);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  function sendMessage(customText) {
    const text = (customText || input).trim();
    if (!text || loading) return;
    setInput("");

    const userMsg = { role: "user", content: text };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);

    // Simulate slight delay for natural feel
    setTimeout(() => {
      const reply = getResponse(text);
      setMessages((prev) => [...prev, { role: "assistant", content: reply }]);
      setLoading(false);
    }, 600);
  }

  return (
    <div style={{ minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center", padding:16, background:"#F7F4F0" }}>
      <div style={{
        width:"100%", maxWidth:660, borderRadius:24, overflow:"hidden",
        display:"flex", flexDirection:"column",
        boxShadow:"0 6px 40px rgba(139,26,26,0.13)",
        background:"#fff", border:"1px solid rgba(139,26,26,0.10)", minHeight:640,
      }}>

        {/* Header */}
        <div style={{ background:"linear-gradient(135deg,#8B1A1A 0%,#A52020 100%)", padding:"18px 20px", display:"flex", alignItems:"center", gap:14 }}>
          <div style={{
            width:48, height:48, borderRadius:12, flexShrink:0,
            background:"rgba(255,255,255,0.15)", border:"1.5px solid rgba(255,255,255,0.3)",
            display:"flex", alignItems:"center", justifyContent:"center",
            fontWeight:700, fontSize:15, color:"#fff",
          }}>AU</div>
          <div>
            <div style={{ fontWeight:700, fontSize:16, color:"#fff" }}>Anna University Assistant</div>
            <div style={{ fontSize:12, color:"rgba(255,255,255,0.72)", marginTop:2, display:"flex", alignItems:"center", gap:5 }}>
              <span style={{ width:7, height:7, background:"#4ADE80", borderRadius:"50%", display:"inline-block" }} />
              Knowledge Base Updated · Runs Locally
            </div>
          </div>
          <div style={{ marginLeft:"auto", background:"rgba(255,255,255,0.15)", borderRadius:20, padding:"4px 10px", fontSize:11, color:"#fff", border:"1px solid rgba(255,255,255,0.25)" }}>
            ✅ 2025–26
          </div>
        </div>

        {/* Update notice */}
        <div style={{ background:"#F0FFF4", borderBottom:"1px solid #BBF7D0", padding:"9px 16px", fontSize:12.5, color:"#166534", display:"flex", alignItems:"center", gap:8 }}>
          <span>🔔</span>
          <span><strong>Knowledge Base Updated!</strong> Latest 2025–26 admissions, fees, NIRF rankings & placement data is now available.</span>
        </div>

        {/* Quick Topics */}
        <div style={{ background:"#fff", borderBottom:"1px solid rgba(139,26,26,0.09)", padding:"9px 14px", display:"flex", gap:7, overflowX:"auto" }}>
          {QUICK_TOPICS.map((t, i) => (
            <button key={i} onClick={() => sendMessage(t.q)}
              onMouseEnter={() => setHovered(i)} onMouseLeave={() => setHovered(null)}
              style={{
                whiteSpace:"nowrap", padding:"5px 12px", borderRadius:20,
                fontSize:12, fontWeight:500, cursor:"pointer", flexShrink:0,
                fontFamily:"inherit", border:"1px solid rgba(139,26,26,0.15)",
                background: hoveredChip === i ? "#8B1A1A" : "#FDF0F0",
                color:      hoveredChip === i ? "#fff"    : "#8B1A1A",
                transition:"all .15s",
              }}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {/* Messages */}
        <div style={{ flex:1, overflowY:"auto", padding:"18px 14px", display:"flex", flexDirection:"column", gap:14, minHeight:340, maxHeight:420 }}>
          {messages.map((msg, i) => (
            <div key={i} style={{ display:"flex", gap:9, alignItems:"flex-end", flexDirection: msg.role==="user" ? "row-reverse" : "row" }}>
              <div style={{
                width:30, height:30, borderRadius:"50%", flexShrink:0,
                display:"flex", alignItems:"center", justifyContent:"center",
                fontSize:10, fontWeight:700,
                background: msg.role==="user" ? "#D4A017" : "#8B1A1A",
                color:      msg.role==="user" ? "#5A3800" : "#fff",
                border: msg.role==="assistant" ? "2px solid rgba(139,26,26,0.2)" : "none",
              }}>
                {msg.role==="user" ? "You" : "AU"}
              </div>
              <div
                style={{
                  maxWidth:"78%", padding:"11px 15px", fontSize:13.5, lineHeight:1.65, borderRadius:18,
                  ...(msg.role==="user"
                    ? { background:"#8B1A1A", color:"#fff", borderBottomRightRadius:4 }
                    : { background:"#fff", border:"1px solid rgba(139,26,26,0.12)", color:"#1A1A1A", borderBottomLeftRadius:4, boxShadow:"0 1px 4px rgba(0,0,0,0.05)" }),
                }}
                dangerouslySetInnerHTML={{ __html: formatText(msg.content) }}
              />
            </div>
          ))}

          {/* Typing dots */}
          {loading && (
            <div style={{ display:"flex", gap:9, alignItems:"flex-end" }}>
              <div style={{ width:30, height:30, borderRadius:"50%", background:"#8B1A1A", color:"#fff", display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, fontWeight:700, border:"2px solid rgba(139,26,26,0.2)", flexShrink:0 }}>AU</div>
              <div style={{ background:"#fff", border:"1px solid rgba(139,26,26,0.12)", borderRadius:18, borderBottomLeftRadius:4, padding:"14px 16px", display:"flex", gap:5, alignItems:"center" }}>
                {[0,1,2].map((j) => (
                  <div key={j} style={{ width:7, height:7, borderRadius:"50%", background:"#8B1A1A", animation:`bounce 1.2s ${j*0.2}s infinite` }} />
                ))}
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div style={{ padding:"12px 14px", background:"#fff", borderTop:"1px solid rgba(139,26,26,0.08)", display:"flex", gap:9, alignItems:"center" }}>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key==="Enter" && sendMessage()}
            placeholder="Ask about admissions, fees, courses..."
            style={{
              flex:1, border:"1.5px solid rgba(139,26,26,0.15)", borderRadius:24,
              padding:"10px 16px", fontSize:13.5, fontFamily:"inherit", outline:"none",
              color:"#1A1A1A", background:"#FAF8F5",
            }}
            onFocus={(e)  => (e.target.style.borderColor="#8B1A1A")}
            onBlur={(e)   => (e.target.style.borderColor="rgba(139,26,26,0.15)")}
          />
          <button onClick={() => sendMessage()}
            style={{ width:42, height:42, borderRadius:"50%", background:"#8B1A1A", border:"none", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}
            onMouseEnter={(e) => (e.currentTarget.style.background="#6B1212")}
            onMouseLeave={(e) => (e.currentTarget.style.background="#8B1A1A")}
          >
            <svg viewBox="0 0 24 24" width="17" height="17" fill="#fff"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
          </button>
        </div>

        <div style={{ textAlign:"center", fontSize:10, color:"#aaa", padding:"5px 0 9px", background:"#fff" }}>
          🏛️ Anna University Knowledge Base · <span style={{ color:"#8B1A1A", fontWeight:500 }}>Runs 100% Locally — No API Key Needed</span>
        </div>
      </div>

      <style>{`
        @keyframes bounce { 0%,100%{opacity:.35;transform:translateY(0)} 50%{opacity:1;transform:translateY(-3px)} }
        * { box-sizing:border-box }
        ::-webkit-scrollbar { width:4px }
        ::-webkit-scrollbar-thumb { background:rgba(139,26,26,0.2);border-radius:4px }
      `}</style>
    </div>
  );
}
